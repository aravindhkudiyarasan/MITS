import boto3
import urllib.request

def write_metric(value, metric):

	d = boto3.client('cloudwatch')
	d.put_metric_data(Namespace='Website Status',
	                  MetricData=[
		                  {
	                  'MetricName':metric,
	                  'Dimensions':[
		                  {
	                  'Name': 'Status',
	                  'Value': 'WebsiteStatusCode',
		                  },
		                  ],
	                  'Value': value,
	},
	]
	                  )

def check_site(url, metric):
	
	STAT = 1
	print("Checking %s " % url)
	request = urllib.request.Request("http://" +url)
	
	try:
		response = urllib.request.urlopen(request)
		response.close()
	except urllib.request.URLError as e:
		if hasattr(e, 'code'):
			print ("[Error:] Connection to %s failed with code: " %url +str(e.code))
			STAT = 100
			write_metric(STAT, metric)
		if hasattr(e, 'reason'):
			print ("[Error:] Connection to %s failed with code: " % url +str(e.reason))
			STAT = 100
			write_metric(STAT, metric)
	except urllib.request.HTTPError as e:
		if hasattr(e, 'code'):
			print ("[Error:] Connection to %s failed with code: " % url + str(e.code))
			STAT = 100
			write_metric(STAT, metric)
		if hasattr(e, 'reason'):
			print ("[Error:] Connection to %s failed with code: " % url + str(e.reason))
			STAT = 100
			write_metric(STAT, metric)
		print('HTTPError!!!')
	
	if STAT != 100:
		STAT = response.getcode()
		
	return STAT

def lambda_handler(event, context):
 
	# Change these to your actual websites.  Remember, the more websites you list
        # the longer the lambda function will run        
	websiteurls = [
		"google.com",
		"in.yahoo.com",
		"www.facebook.com",
		"dummy.com",
		"example.com"
		
	]
	metricname = 'Site Availability'
	
	for site in websiteurls:
		r = check_site(site,metricname)
		if r == 200 or r == 304:
			print("Site %s is up" %site)
			write_metric(200, metricname)
		else:
			print("[Error:] Site %s down" %site)
			write_metric(50, metricname)